/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetovendas.interfaces;

/**
 *
 * @author aluno
 */
public interface IOperacao {
    public void cadastrar();
    public boolean alterar();
    public boolean excluir();
    public void cancelar();
    
}
